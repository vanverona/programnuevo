﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAni
{
    public class Mamiferos : Animales
    {
        public override void getNombre(string nom)
        {
            Console.WriteLine(nom);
        }

        public void pensar()
        {
            Console.WriteLine("Piensa");
        }

        public void cuidarCrias()
        {
            Console.WriteLine("Cuida crias");
        }
    }
}
