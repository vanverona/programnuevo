﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAni
{
  public class Humano : Mamiferos, MamiferosTerrestres
    {
        public void numeroPatas(string numPatas)
        {
            Console.WriteLine("Tiene "+numPatas+" patas");
        }
    }
}
