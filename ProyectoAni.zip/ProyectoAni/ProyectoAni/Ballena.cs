﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAni
{
   public class Ballena:Mamiferos
    {
        public void nadar()
        {
            Console.WriteLine("La ballena esta nadando" + " su nombre es ");
        }
    }
}
