﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAni
{
    class Program
    {
        static void Main(string[] args)
        {
            Lagartija lagar = new Lagartija();

            lagar.getNombre("Ann");
            lagar.numeroPatas("4");
            lagar.respirar();

             Humano hum = new Humano ();
            hum.getNombre("Simon");
            hum.cuidarCrias();
            hum.numeroPatas("2");

            Ballena ball = new Ballena();

            ball.nadar();
            ball.getNombre("Doris");

            Caballo cab = new Caballo();
            cab.getNombre("Isa");
            cab.galopar();
            cab.numeroPatas("4");

            Gorilas gor = new Gorilas();

            gor.getNombre("Manuel");
            gor.cuidarCrias();
            gor.numeroPatas("2");



            Console.Read();
        }
    }
}
