﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using zoologico.Utilidades;

namespace zoologico.MainForm
{
    class querys
    {
        private connectionToDB controller = new connectionToDB();
        string query = "";
        private bool dbAccess = false;

        public DataSet listar()
        {
            Cursor.Current = Cursors.WaitCursor;

            dbAccess = false;
            DataSet data = new DataSet();
            query = "SELECT * FROM tblAnimales";
            dbAccess = controller.openConnection();

            if (dbAccess)
            {
                controller.adapter = new SqlDataAdapter(query, controller.dbConnection);
                controller.adapter.Fill(data, "tblAnimales");
            }

            Cursor.Current = Cursors.Default;
            return data;
        }

        public bool eliminar(int id)
        {
            Cursor.Current = Cursors.WaitCursor;

            dbAccess = false;
            bool eliminado = false;
            DataSet insertar = new DataSet();
            query = ($"DELETE FROM tblAnimales WHERE idAnimal = {id}");
            dbAccess = controller.openConnection();
            if (dbAccess)
            {
                controller.adapter = new SqlDataAdapter(query, controller.dbConnection);
                controller.adapter.Fill(insertar, "tblAnimales");
                eliminado = true;
            }

            Cursor.Current = Cursors.Default;
            return eliminado;
        }
    }
}
