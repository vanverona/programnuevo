﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using zoologico.MainForm;
using zoologico.Utilidades;

namespace zoologico
{
    public partial class Form1 : Form
    {

        private querys manipulacion = new querys();

        public Form1()
        {
            InitializeComponent();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            AgregarEditarForm.AgregarEditar agregar = new AgregarEditarForm.AgregarEditar();
            agregar.setFatherForm(this);
            agregar.Show();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            AgregarEditarForm.AgregarEditar agregar = new AgregarEditarForm.AgregarEditar();
            agregar.Text = "Editar | Parque Zoológico de León";
            agregar.setFatherForm(this);

            // propiedades
            agregar.id = dgvDatos.Rows[dgvDatos.CurrentRow.Index].Cells[0].Value.ToString();
            agregar.txtNombre.Text = dgvDatos.Rows[dgvDatos.CurrentRow.Index].Cells[1].Value.ToString();
            agregar.txtComida.Text = dgvDatos.Rows[dgvDatos.CurrentRow.Index].Cells[2].Value.ToString();
            agregar.txtHabitad.Text = dgvDatos.Rows[dgvDatos.CurrentRow.Index].Cells[3].Value.ToString();
            agregar.txtAnios.Text = dgvDatos.Rows[dgvDatos.CurrentRow.Index].Cells[4].Value.ToString();
            agregar.txtPeso.Text = dgvDatos.Rows[dgvDatos.CurrentRow.Index].Cells[5].Value.ToString();
            agregar.txtLargo.Text = dgvDatos.Rows[dgvDatos.CurrentRow.Index].Cells[6].Value.ToString();
            agregar.txtAncho.Text = dgvDatos.Rows[dgvDatos.CurrentRow.Index].Cells[7].Value.ToString();

            agregar.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            llenarDGV();
        }

        public void llenarDGV()
        {
            dgvDatos.DataSource = manipulacion.listar();
            dgvDatos.DataMember = "tblAnimales";
            dgvDatos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dgvDatos.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dgvDatos.Columns[0].HeaderText = "ID";
            dgvDatos.Columns[1].HeaderText = "Nombre";
            dgvDatos.Columns[2].HeaderText = "Comida";
            dgvDatos.Columns[3].HeaderText = "Hábitad";
            dgvDatos.Columns[4].HeaderText = "Años";
            dgvDatos.Columns[5].HeaderText = "Peso";
            dgvDatos.Columns[6].HeaderText = "Largo";
            dgvDatos.Columns[7].HeaderText = "Ancho";
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            if (dgvDatos.CurrentRow != null)
            {
                if (messages.areYourSure_delete() == true)
                {
                    manipulacion.eliminar(int.Parse(dgvDatos.Rows[dgvDatos.CurrentRow.Index].Cells[0].Value.ToString()));
                    llenarDGV();
                }
            }
            else
            {
                messages.selectARow();
            }
        }


    }
}
