﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zoologico.Utilidades
{
    class connectionToDB
    {
        public SqlConnection dbConnection;
        public SqlDataAdapter adapter;

        public bool openConnection()
        {
            bool open = false;
            string connectionString = ($"Data Source={Environment.MachineName};Initial Catalog=ZOO;Integrated Security=True");

            try
            {
                dbConnection = new SqlConnection(connectionString);
                dbConnection.Open();
                open = true;
            }
            catch (Exception)
            {
                messages.failedToConnect();
            }
            return open;
        }
    }
}
