﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zoologico.Utilidades
{
    class Animal
    {
        public int idAnimal { get; set; }
        public string nombre { get; set; }
        public string comida { get; set; }
        public string habitad { get; set; }
        public int anios { get; set; }
        public decimal peso { get; set; }
        public decimal largo { get; set; }
        public decimal ancho { get; set; }
    }
}
