﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zoologico.Utilidades
{
    class messages
    {

        public static void failedToConnect()
        {
            MessageBox.Show(
                "No se puede conectar al servidor, contacte al Administrador. Asegurese de que el servidor está encendido y conectado en la red.",
                "Sin respuesta del servidor",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
        }

        public static bool areYourSure_delete()
        {
            DialogResult dialogResult = MessageBox.Show("¿Está seguro que desea eliminar permanentemente esta información? Esta acción no se puede deshacer", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void selectARow()
        {
            MessageBox.Show(
                "Selecciona un registro",
                "Atención",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }
    }
}
