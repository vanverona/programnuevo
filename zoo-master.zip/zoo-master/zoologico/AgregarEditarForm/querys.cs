﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using zoologico.Utilidades;

namespace zoologico.AgregarEditarForm
{
    class querys
    {
        private connectionToDB controller = new connectionToDB();
        string query = "";
        private bool dbAccess = false;

        public bool insertar(Animal newAnimal)
        {
            Cursor.Current = Cursors.WaitCursor;

            dbAccess = false;
            bool insertado = false;
            DataSet insertar = new DataSet();
            query = ($"INSERT INTO tblAnimales VALUES ('{newAnimal.nombre}', '{newAnimal.comida}', '{newAnimal.habitad}', '{newAnimal.anios}', '{newAnimal.peso}', '{newAnimal.largo}', '{newAnimal.ancho}')");
            dbAccess = controller.openConnection();
            if (dbAccess)
            {
                controller.adapter = new SqlDataAdapter(query, controller.dbConnection);
                controller.adapter.Fill(insertar, "tblAnimales");
                insertado = true;
            }

            Cursor.Current = Cursors.Default;
            return insertado;
        }

        public bool editar(Animal newAnimal)
        {
            Cursor.Current = Cursors.WaitCursor;

            dbAccess = false;
            bool editado = false;
            DataSet insertar = new DataSet();
            query = ($"UPDATE tblAnimales SET nombre = '{newAnimal.nombre}', comida = '{newAnimal.comida}', habitad = '{newAnimal.habitad}', anios = '{newAnimal.anios}', peso = '{newAnimal.peso}', largo = {newAnimal.largo}, ancho = {newAnimal.ancho} WHERE idAnimal = {newAnimal.idAnimal}");
            dbAccess = controller.openConnection();
            if (dbAccess)
            {
                controller.adapter = new SqlDataAdapter(query, controller.dbConnection);
                controller.adapter.Fill(insertar, "tblAnimales");
                editado = true;
            }

            Cursor.Current = Cursors.Default;
            return editado;
        }

    }
}
