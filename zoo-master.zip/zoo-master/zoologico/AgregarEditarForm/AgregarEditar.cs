﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zoologico.AgregarEditarForm
{

    public partial class AgregarEditar : Form
    {

        private querys manipulacion = new querys();
        private Form1 mainForm = new Form1();
        public string id = null;

        public AgregarEditar()
        {
            InitializeComponent();
        }

        public void setFatherForm(Form1 form)
        {
            mainForm = form;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (id == null)
            {
                Guardar();
                mainForm.llenarDGV();
                limpiarCampos();
            }
            else
            {
                Actualizar();
                mainForm.llenarDGV();
                this.Dispose();
            }
            
        }

        private void Guardar()
        {
            Utilidades.Animal animal = new Utilidades.Animal();
            animal.nombre = txtNombre.Text;
            animal.comida = txtComida.Text;
            animal.habitad = txtHabitad.Text;
            animal.anios = int.Parse(txtAnios.Text);
            animal.peso = decimal.Parse(txtPeso.Text);
            animal.largo = decimal.Parse(txtLargo.Text);
            animal.ancho = decimal.Parse(txtAncho.Text);

            manipulacion.insertar(animal);
        }

        private void Actualizar()
        {
            Utilidades.Animal animal = new Utilidades.Animal();
            animal.idAnimal = int.Parse(id);
            animal.nombre = txtNombre.Text;
            animal.comida = txtComida.Text;
            animal.habitad = txtHabitad.Text;
            animal.anios = int.Parse(txtAnios.Text);
            animal.peso = decimal.Parse(txtPeso.Text);
            animal.largo = decimal.Parse(txtLargo.Text);
            animal.ancho = decimal.Parse(txtAncho.Text);

            manipulacion.editar(animal);
        }

        private void limpiarCampos()
        {
            txtNombre.Text = "";
            txtComida.Text = "";
            txtHabitad.Text = "";
            txtAnios.Value = 0;
            txtPeso.Value = decimal.Parse("0.00");
            txtLargo.Value = decimal.Parse("0.00");
            txtAncho.Value = decimal.Parse("0.00");
        }
    }
}
